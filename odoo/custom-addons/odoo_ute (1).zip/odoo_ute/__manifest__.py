{
    'name': 'Gestión Académica UTE',
    'version': '19.0.1.0.0',
    'category': 'Education',
    'summary': 'Administración de alumnos, maestros, cursos, calificaciones y asistencias',
    'author': 'Emily Torres',
    'depends': ['base'],
    'data': [
        
        'security/groups.xml',
        'security/ir.model.access.csv',
        'security/ir.rule.xml',
        'views/maestro_views.xml',
        'views/alumno_views.xml',
        'views/cursos_views.xml',
        'views/calificacion_views.xml',
        'views/asistencia_views.xml',
        'views/menu_views.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
